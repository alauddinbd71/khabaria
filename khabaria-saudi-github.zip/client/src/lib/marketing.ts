export type MarketingEvent = {
  name: string;
  params?: Record<string, string | number | boolean | undefined>;
};

type Attribution = Record<string, string>;

const STORAGE_KEY = "khabaria-attribution";
const ATTRIBUTION_KEYS = ["utm_source", "utm_medium", "utm_campaign", "utm_content", "utm_term", "gclid", "fbclid", "ttclid"];

function readStoredAttribution(): Attribution {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}") as Attribution;
  } catch {
    return {};
  }
}

export function captureAttribution(): Attribution {
  const stored = readStoredAttribution();
  const params = new URLSearchParams(window.location.search);
  const current: Attribution = { ...stored };
  ATTRIBUTION_KEYS.forEach((key) => {
    const value = params.get(key);
    if (value) current[key] = value;
  });
  if (!current.landing_page) current.landing_page = window.location.pathname;
  if (!current.first_touch_at) current.first_touch_at = new Date().toISOString();
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(current)); } catch { /* Storage can be unavailable in private browsing. */ }
  return current;
}

export function getAttribution(): Attribution {
  return readStoredAttribution();
}

export function trackEvent({ name, params = {} }: MarketingEvent): void {
  const attribution = getAttribution();
  const enriched = { ...params, ...attribution };
  window.dataLayer = window.dataLayer || [];
  window.dataLayer.push({ event: name, ...enriched });
  if (typeof window.gtag === "function") window.gtag("event", name, enriched);
  if (typeof window.fbq === "function") {
    const metaEvent = name === "generate_lead" ? "Lead" : name === "view_content" ? "ViewContent" : name;
    window.fbq("track", metaEvent, enriched);
  }
}

export function trackWhatsAppClick(label: string): void {
  trackEvent({ name: "generate_lead", params: { method: "whatsapp", cta_label: label } });
}

declare global {
  interface Window {
    dataLayer: Array<Record<string, unknown>>;
    gtag?: (...args: unknown[]) => void;
    fbq?: (...args: unknown[]) => void;
  }
}
